"""
 Version file.
 Allows common version lookup via from dataclasses_json import __version__
"""

__version__ = "0.6.2"  # replaced by git tag on deploy
