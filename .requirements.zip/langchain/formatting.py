"""DEPRECATED: Kept for backwards compatibility."""
from langchain.utils.formatting import StrictFormatter, formatter

__all__ = ["StrictFormatter", "formatter"]
