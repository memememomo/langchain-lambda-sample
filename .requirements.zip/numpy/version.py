
version = "1.26.2"
__version__ = version
full_version = version

git_revision = "03b62604eead0f7d279a5a4c094743eb29647368"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
